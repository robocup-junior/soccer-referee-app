package com.robocup.rcj_scoreboard

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
