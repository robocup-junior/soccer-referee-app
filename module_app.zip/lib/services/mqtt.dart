// lib/services/mqtt_service.dart
import 'dart:async';
import 'dart:io';
//import 'packagepackage:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';
import 'package:uuid/uuid.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';


class MqttService {
  MqttServerClient? _client;
  final String _main_topic = 'rcj_soccer'; // To store the configured topic
  String _topic = ''; // To store the configured topic
  late int _port; // To store the configured port
  late String _server; // To store the configured server
  late String _username; // To store the configured username
  late String _password; // To store the configured password
  final String _clientIdentifier = 'client_${const Uuid().v4()}'; // Generate unique client ID
  final ValueNotifier<bool> isConnectedNotifier = ValueNotifier(false);
  late SharedPreferences prefs;

  final StreamController<String> _messageStreamController = StreamController<
      String>.broadcast();

  Stream<String> get messageStream => _messageStreamController.stream;

  MqttService() {
    loadPreferences(); // Load preferences on initialization
  }

  /// Loads MQTT settings from SharedPreferences
  Future<void> loadPreferences() async {
    prefs = await SharedPreferences.getInstance();
    _topic = prefs.getString('mqtt_topic') ?? '';
    _port = prefs.getInt('mqtt_port') ?? 8883;
    _server = prefs.getString('mqtt_server') ?? '17f77fae84fb4deb9d73bd303ca98e12.s1.eu.hivemq.cloud';
    _username = prefs.getString('mqtt_username') ?? 'rcj_soccer';
    _password = prefs.getString('mqtt_password') ?? 'RCJmqtt123';
  }


  // Getters for server, port, username, and password
  String? get server => _server;
  int? get port => _port;
  String? get username => _username;
  String? get password => _password;
  String get topic => _topic;

  // Setters for server, port, username, and password
  set server(String? value) {
    if (value != null && value.isNotEmpty) {
      _server = value;
      // Save to preferences
      prefs.setString('mqtt_server', value);
    } else {
      print('MQTT_LOGS::Error: Invalid server address.');
    }
  }

  set port(int? value) {
    if (value != null && value > 0) {
      _port = value;
      // Save to preferences
      prefs.setInt('mqtt_port', value);
    } else {
      print('MQTT_LOGS::Error: Invalid port number.');
    }
  }

  set username(String? value) {
    if (value != null) {
      _username = value;
      // Save to preferences
      prefs.setString('mqtt_username', value);
    } else {
      print('MQTT_LOGS::Error: Invalid username.');
    }
  }

  set password(String? value) {
    if (value != null) {
      _password = value;
      // Save to preferences
      prefs.setString('mqtt_password', value);
    } else {
      print('MQTT_LOGS::Error: Invalid password.');
    }
  }

  set topic(String value) {
    if (value.isNotEmpty) {
      _topic = value;
      // Save to preferences
      prefs.setString('mqtt_topic', value);
    } else {
      print('MQTT_LOGS::Error: Invalid topic.');
    }
  }

  bool get isConnected =>
      _client?.connectionStatus?.state == MqttConnectionState.connected;


  Future<bool> connect() async {

    if (_server == null || _port == null) {
          print('MQTT_LOGS::Error: Server or port not set.');
          return false;
    }

    _client = MqttServerClient.withPort(_server, _clientIdentifier, _port);
    _client!.logging(
        on: false); // Disable logging for production, enable for debugging
    if (_port != 1883) {
      _client!.secure = true; // <--- THIS IS CRUCIAL FOR PORT 8883
    }

    _client!.keepAlivePeriod = 60;
    _client!.onDisconnected = _onDisconnected;
    _client!.onConnected = _onConnected;
    _client!.onSubscribed = _onSubscribed;
    _client!.pongCallback = _pong; // Optional: for keep alive

    final connMess = MqttConnectMessage()
        .withClientIdentifier(_clientIdentifier)
        .withWillTopic('willtopic') // Optional: Example Will topic
        .withWillMessage('My Will message') // Optional: Example Will message
        .startClean() // Non persistent session
        .withWillQos(MqttQos.atLeastOnce);

  if (_username.isNotEmpty && _password.isNotEmpty) {
    connMess.authenticateAs(_username, _password);
  }

    _client!.connectionMessage = connMess;

    try {
    print('MQTT_LOGS::Connecting to $_server:$_port...');
    await _client!.connect(_username, _password); // Pass username/password again here for some brokers
    } on NoConnectionException catch (e) {
    print('MQTT_LOGS::Client exception - $e');
    _client!.disconnect();
    return false;
    } on SocketException catch (e) {
    print('MQTT_LOGS::Socket exception - $e');
    _client!.disconnect();
    return false;
    }

    if (_client!.connectionStatus!.state == MqttConnectionState.connected) {
    print('MQTT_LOGS::Mosquitto client connected');
    _subscribeToTopic(_main_topic);
    return true;
    } else {
    print('MQTT_LOGS::ERROR Mosquitto client connection failed - disconnecting, status is ${_client!.connectionStatus}');
    _client!.disconnect();
    return false;
    }
  }

  void _subscribeToTopic(String topic) {
    if (_client != null &&
        _client!.connectionStatus!.state == MqttConnectionState.connected) {
      print('MQTT_LOGS::Subscribing to the topic $topic');
      _client!.subscribe(topic, MqttQos.atMostOnce); // Or other QoS level

      // Listen for incoming messages
      _client!.updates!.listen((List<MqttReceivedMessage<MqttMessage?>>? c) {
        final recMess = c![0].payload as MqttPublishMessage;
        final pt = MqttPublishPayload.bytesToStringAsString(
            recMess.payload.message!);
        _messageStreamController.add(pt);
        print('MQTT_LOGS::Received message: $pt from topic: ${c[0].topic}>');
      });
    }
  }

  void publishMessage(String message, {String? specificTopic}) {
    if (_client != null &&
        _client!.connectionStatus!.state == MqttConnectionState.connected) {
      final topicToPublish = specificTopic ?? _main_topic;
      if (topicToPublish == null) {
        print('MQTT_LOGS::Error: Topic not set for publishing.');
        return;
      }
      final builder = MqttClientPayloadBuilder();
      builder.addString(message);
      _client!.publishMessage(
          topicToPublish, MqttQos.atLeastOnce, builder.payload!);
      print('MQTT_LOGS::Published message: $message to topic: $topicToPublish');
    } else {
      print('MQTT_LOGS::Client not connected. Cannot publish.');
    }
  }

  /// Publishes a message to a topic specific for the communication module.
    /// The topic will be: _main_topic/[_topic]/[topic] if _topic is not empty, otherwise _main_topic/[topic].
    void publishCMMessage(String message, {required String topic}) {
      String fullTopic;
      if (_topic.isNotEmpty) {
        fullTopic = '$_main_topic/$_topic/$topic';
      } else {
        fullTopic = '$_main_topic/$topic';
      }
      publishMessage(message, specificTopic: fullTopic);
    }

  void disconnect() {
    if (_client != null) {
      print('MQTT_LOGS::Disconnecting client');
      _client!.disconnect();
      _client = null;
    }
  }

  void _onConnected() {
    print('MQTT_LOGS::Client connection was successful');
    isConnectedNotifier.value = true;
    // If you need to re-subscribe on auto-reconnect, do it here
    // if (_topic != null) {
    //   _subscribeToTopic(_topic!);
    // }
  }

  void _onDisconnected() {
    print('MQTT_LOGS::Client disconnected');
    isConnectedNotifier.value = false;
    if (_client != null && _client!.connectionStatus!.disconnectionOrigin ==
        MqttDisconnectionOrigin.solicited) {
      print(
          'MQTT_LOGS::Disconnected callback is solicited, not attempting reconnection');
    }
    // You might want to implement reconnection logic here if needed
  }

  void _onSubscribed(String topic) {
    print('MQTT_LOGS::Subscribed to topic: $topic');
  }

  void _pong() {
    print('MQTT_LOGS::Ping response client callback invoked');
  }

  void dispose() {
    _messageStreamController.close();
    disconnect();
  }
}