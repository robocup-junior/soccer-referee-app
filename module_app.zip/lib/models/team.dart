import 'package:flutter/foundation.dart';
import 'package:rcj_scoreboard/models/module.dart';

class Team with ChangeNotifier {
  final String name;
  final String id;
  final List<Module> modules;
  int score = 0;

  Team(this.name, this.modules, this.id);

  void addScore(int value) {
    if (value < 0 && score <= 0) return;
    score += value;
    notifyListeners();
  }
}