import 'package:flutter/foundation.dart';
import 'package:rcj_scoreboard/models/module.dart';
import 'dart:async';
import 'package:rcj_scoreboard/models/team.dart';
import 'package:rcj_scoreboard/services/mqtt.dart';

enum MatchStage {
  firstHalf,
  halfTime,
  secondHalf,
  fullTime,
}

class Game with ChangeNotifier {
  String timerButtonText = 'START';
  final int _maxPlayer = 5;
  final List<Team> teams = [];
  int numberOfPLayers = 2;
  int _remainingTime = 0;
  int penaltyTime = 60;
  int periodTime = 600;
  int halfTimeDuration = 300;
  bool _isGameRunning = false;
  bool inGame = false;
  bool isTimeRunning = false;
  int _numberOfPlaying = 0;
  MatchStage currentStage = MatchStage.firstHalf;
  Timer? _timer;
  //MQTT
  MqttService mqttService = MqttService();

  Game() {


    // A team (0)
    Module moduleA1 = Module(this, 0, 'A1');
    Module moduleA2 = Module(this, 0, 'A2');
    Module moduleA3 = Module(this, 0, 'A3');
    Module moduleA4 = Module(this, 0, 'A4');
    Module moduleA5 = Module(this, 0, 'A5');
    teams.add(Team('Team A', [moduleA1, moduleA2, moduleA3, moduleA4 ,moduleA5], 'team_a'));

    // B team (1)
    Module moduleB1 = Module(this, 1, 'B1');
    Module moduleB2 = Module(this, 1, 'B2');
    Module moduleB3 = Module(this, 1, 'B3');
    Module moduleB4 = Module(this, 1, 'B4');
    Module moduleB5 = Module(this, 1, 'B5');
    teams.add(Team('Team B', [moduleB1, moduleB2, moduleB3, moduleB4 ,moduleB5], 'team_b'));


    gameInit();
  }

  void gameInit() {
    currentStage = MatchStage.firstHalf;
    _remainingTime = periodTime;
    isTimeRunning = false;
    _isGameRunning = false;
    timerButtonText = 'START';
    inGame = false;

    // set mqtt values to default
    mqttService.publishCMMessage(gameStageString, topic: 'game_stage');
    mqttService.publishCMMessage(
      '${(_remainingTime ~/ 60).toString().padLeft(2, '0')}:${(_remainingTime % 60).toString().padLeft(2, '0')}',
      topic: 'time',
    );

    stopTimer();

    // enable or disable players based on player number;
    for (var team in teams) {
      team.score = 0;
      mqttService.publishCMMessage(team.score.toString(), topic: "${team.id}_score");
      for (var i = 0; i < _maxPlayer; i++) {
        i < numberOfPLayers ? team.modules[i].enable() : team.modules[i].disable();
        team.modules[i].init();
      }
    }
    notifyListeners();
  }


  // Timer

  void startTimer() {
    _timer?.cancel();
    inGame = true;
    if (currentStage == MatchStage.firstHalf || currentStage == MatchStage.secondHalf) {
      _isGameRunning = true;
    }
    isTimeRunning = true;
    notifyListeners();
    _timer = Timer.periodic(Duration(seconds: 1), (timer) {
      if (_remainingTime > 0) {
        _remainingTime--;
        notifyAllModulesTimer();
        mqttService.publishCMMessage(
          '${(_remainingTime ~/ 60).toString().padLeft(2, '0')}:${(_remainingTime % 60).toString().padLeft(2, '0')}',
          topic: 'time',
        );
      }

      if (_remainingTime <= 0) {
        _isGameRunning = false;
        isTimeRunning = false;
        timer.cancel();

        switch (currentStage) {
          case MatchStage.firstHalf:
            currentStage = MatchStage.halfTime;
            _remainingTime = halfTimeDuration;
            startTimer();
            timerButtonText = 'SKIP';
            halfTimeAll();
          case MatchStage.halfTime:
            currentStage = MatchStage.secondHalf;
            _remainingTime = periodTime;
            stopAll(true, force: true);
            timerButtonText = 'START';
          case MatchStage.secondHalf:
            currentStage = MatchStage.fullTime;
            stopAll(true);
            timerButtonText = 'REPEAT';
            gameOverAll();
          default:
            print('unknown match stage');
        }

        mqttService.publishCMMessage(gameStageString, topic: 'game_stage');

      }

      if (currentStage == MatchStage.halfTime && _remainingTime % 30 == 0) {
        halfTimeSyncTimeAll();
      }

      notifyListeners();
    });
  }

  void toggleTimer() {
    if (currentStage == MatchStage.firstHalf || currentStage == MatchStage.secondHalf) {
      if (_isGameRunning) {
        stopTimer();
        timerButtonText = 'START';
        stopAll(false);
      } else {
        timerButtonText = 'STOP';
        startTimer();
        playAll(false);
      }
    } else if (currentStage == MatchStage.halfTime) {
      // SKIP
      _isGameRunning = false;
      isTimeRunning = false;
      _timer?.cancel();
      currentStage = MatchStage.secondHalf;
      _remainingTime = periodTime;
      stopAll(true, force: true);
      timerButtonText = 'START';
      mqttService.publishCMMessage(gameStageString, topic: 'game_stage');

      notifyListeners();
    } else {
      // GAME OVER
      gameInit();
      notifyListeners();
    }
  }

  void toggleAllModules() {
    if (currentStage == MatchStage.fullTime) {
      disconnectAll();
    } else if (_numberOfPlaying > 0) {
      stopAll(true);
    } else {
      if (!_isGameRunning && (currentStage == MatchStage.firstHalf || currentStage == MatchStage.secondHalf)) {
        startTimer();
        timerButtonText = 'STOP';
      }
      playAll(true);
    }
  }

  void notifyAllModulesTimer() {
    for (var team in teams) {
      for (var module in team.modules.where((module) => module.isEnabled && module.state == ModuleState.damage)) {
        module.notifyTimer();
      }
    }
  }


  void stopTimer() {
    _isGameRunning = false;
    isTimeRunning = false;
    _timer?.cancel();
    notifyListeners();
  }



  void playAll(bool removeDamage) async {
    for (var team in teams) {
      for (var module in team.modules.where((module) => module.isEnabled)) {
        if (removeDamage) {
          module.playAll();
        } else {
          module.playOrDamageAll();
        }

      }
    }
    notifyListeners();
  }

  void stopAll(bool removePenalty, {bool force = false}) {
    for (var team in teams) {
      for (var module in team.modules.where((module) => module.isEnabled)) {
        module.stopAll(removePenalty, force: force);
      }
    }
    notifyListeners();
  }

  void disconnectAll() {
    for (var team in teams) {
      for (var module in team.modules.where((module) => module.isEnabled && module.isConnected)) {
        module.bleDisconnect();
      }
    }
  }

  void halfTimeAll() async {
    stopAll(true);
    await Future.delayed(const Duration(seconds: 1));

    for (var team in teams) {
      for (var module in team.modules.where((module) => module.isEnabled)) {
        module.halfTime();
      }
    }
    notifyListeners();
  }

  void gameOverAll() async {
    stopAll(true);
    await Future.delayed(const Duration(seconds: 1));

    for (var team in teams) {
      for (var module in team.modules.where((module) => module.isEnabled)) {
        module.gameOver();
      }
    }
    notifyListeners();
  }

  void halfTimeSyncTimeAll() {
    for (var team in teams) {
      for (var module in team.modules.where((module) => module.isEnabled && module.isConnected)) {
        module.halfTimeSyncTime();
      }
    }
  }

  int getScore(int team) {
    return teams[team].score;
  }

  void notifyModulesScore() {
    for (var team in teams) {
      mqttService.publishCMMessage(team.score.toString(), topic: "${team.id}_score");
      for (var module in team.modules.where((module) => module.isEnabled && module.isConnected)) {
        module.bleSendScore();
        print('score sent');
      }
    }
  }


  void changeNumberOfPlaying(int add) {
    _numberOfPlaying += add;

    if (_numberOfPlaying < 0) _numberOfPlaying = 0;
    if (_numberOfPlaying > numberOfPLayers*2) _numberOfPlaying = numberOfPLayers*2;

    if (_numberOfPlaying < 2) notifyListeners();
  }

  // void checkNumOfPlaying() {
  //   bool current = false;
  //   for (var team in teams) {
  //     for (var module in team.modules.where((module) => module.isEnabled)) {
  //       if (module.isPlaying) {
  //         current = true;
  //         break;
  //       }
  //       if(current) break;
  //     }
  //   }
  //
  //   //if (!current) stopAll();
  //
  //   if (current != _isSomeonePlaying) {
  //     _isSomeonePlaying = current;
  //     notifyListeners();
  //   }
  //
  // }


  int get remainingTime => _remainingTime;
  bool get isSomeonePlaying => _numberOfPlaying > 0 ? true : false;
  bool get isTimerRunning => isTimeRunning;
  bool get isGameRunning => _isGameRunning;
  String get gameStageString {
    switch (currentStage) {
      case MatchStage.firstHalf:
        return '1';
      case MatchStage.halfTime:
        return 'Half-Time';
      case MatchStage.secondHalf:
        return '2';
      case MatchStage.fullTime:
        return 'Game Over';
    }
  }
}