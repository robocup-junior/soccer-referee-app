import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:rcj_scoreboard/screens/module_settings.dart';
import 'package:rcj_scoreboard/models/game.dart';
import 'package:rcj_scoreboard/models/team.dart';
import 'package:rcj_scoreboard/models/module.dart';
import 'package:flutter/services.dart';
import 'package:rcj_scoreboard/screens/mac_qr_scanner.dart';
import 'package:rcj_scoreboard/screens/settings.dart';

class Home extends StatelessWidget {
  Home({super.key});

  void _navigateToSettings(context, Game game) async {
    final updatedGame = await Navigator.push<Game>(
      context,
      MaterialPageRoute(
        builder: (context) => SettingsScreen(game: game),
      ),
    );

    if (updatedGame != null && !game.inGame) {
      game.gameInit();
    }
  }

  @override
  Widget build(BuildContext context) {
    final game = Provider.of<Game>(context);

    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        debugPrint("didPop1: $didPop");
        if (didPop) {
          return;
        }
        final bool shouldPop = await _showExitDialog(context);
        if (shouldPop) {
          SystemNavigator.pop();
        }
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          backgroundColor: Colors.blue[900],
          title: const Text('RCJ Soccer - Score Board',
              style: TextStyle(color: Colors.white)),
          actions: [
            IconButton(
              icon: Icon(Icons.settings),
              color: Colors.white,
              onPressed: () {
                _navigateToSettings(context, game);
              },
                // Navigate to config page
            ),
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: <Widget>[
              Expanded(
                flex: 6,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      flex: 1,
                      child: buildTeamContainer(game.teams[0], game),
                    ),
                    Expanded(
                      flex: 1,
                      child: Column(
                        children: [
                          Text(
                              '${(game.remainingTime ~/ 60).toString().padLeft(2, '0')}:${(game.remainingTime % 60).toString().padLeft(2, '0')}',
                              style: const TextStyle(fontSize: 40.0)),
                          Text(game.gameStageString),
                          Container(
                            width: double.infinity,
                            child: GestureDetector(
                              onDoubleTap: () {
                                game.toggleTimer();
                              },
                              child: ElevatedButton(
                                onPressed: () {},
                                style: ElevatedButton.styleFrom(
                                  //minimumSize: const Size(120, 50),
                                  backgroundColor: (game.isGameRunning
                                      ? (game.isTimerRunning
                                          ? Colors.red
                                          : Colors.green)
                                      : Colors.green),
                                ),
                                child: Text(game.timerButtonText,
                                    style: TextStyle(color: Colors.white)),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: buildTeamContainer(game.teams[1], game),
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 20,
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        children: game.teams[0].modules
                            .where((module) => module.isEnabled)
                            .map((module) => buildModuleButton(module, game))
                            .toList(),
                      ),
                    ),
                    Expanded(
                      child: Column(
                        children: game.teams[1].modules
                            .where((module) => module.isEnabled)
                            .map((module) => buildModuleButton(module, game))
                            .toList(),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 4,
                child: Container(
                  margin: const EdgeInsets.all(4.0),
                  width: double.infinity,
                  //height: 70.0,
                  child: GestureDetector(
                    onDoubleTap: () {
                      game.toggleAllModules();
                    },
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor:
                            (game.currentStage == MatchStage.fullTime
                                ? Colors.blue[700]
                                : (game.isSomeonePlaying
                                    ? Colors.red
                                    : Colors.green)),
                        // shape: RoundedRectangleBorder(
                        //   borderRadius: BorderRadius.circular(30.0),
                        // )
                      ),
                      child: Text(
                          game.currentStage == MatchStage.fullTime
                              ? 'DISCONNECT ALL ROBOTS'
                              : (game.isSomeonePlaying
                                  ? 'STOP ALL ROBOTS'
                                  : 'START ALL ROBOTS'),
                          style: TextStyle(color: Colors.white)),
                      onPressed: () {},
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Widget buildModuleButton(Module module, Game game) {
  return ChangeNotifierProvider.value(
    value: module,
    child: Consumer<Module>(
      builder: (context, module, child) {
        return Expanded(
          child: GestureDetector(
            onDoubleTap: () {
              if (module.isPlaying) {
                if (game.isGameRunning) {
                  module.penalty(game.penaltyTime);
                } else {
                  module.stop();
                }
              } else {
                module.play();
              }
            },
            onLongPress: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ChangeNotifierProvider.value(
                  value: module,
                  child: ModuleSettingsScreen(),
                ),
              ),
            ),
            // onLongPress: () => Navigator.push(context,
            //   MaterialPageRoute(builder: (context) => ModuleSettingsScreen(module: module)),
            // ),
            child: Container(
              margin: const EdgeInsets.all(4.0),
              decoration: BoxDecoration(
                  color: module.isConnected
                      ? (module.isPlaying ? Colors.green : Colors.red)
                      : Colors.blue[700],
                  borderRadius: BorderRadius.circular(
                      10.0), // Adjust this value to control the roundness
                  border: Border(
                      bottom: BorderSide(
                    width: 5,
                    color: module.isPlaying ? Colors.green : Colors.red,
                  ))),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      module.name,
                      textAlign:
                          TextAlign.center, // Ensure the text is centered
                      style: const TextStyle(fontSize: 30, color: Colors.white),
                    ),
                    Text(
                      module.currentPenalty,
                      style: const TextStyle(fontSize: 18, color: Colors.white),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    ),
  );
}

Widget buildTeamContainer(Team team, Game game) {
  return ChangeNotifierProvider.value(
    value: team,
    child: Consumer<Team>(
      builder: (context, team, child) {
        return GestureDetector(
          onDoubleTap: () {
            team.addScore(1);
            game.stopAll(true);
            game.notifyModulesScore();
          },
          onLongPress: () {
            showModalBottomSheet(
                context: context,
                builder: (context) {
                  return Container(
                    //height: 100,
                    color: Colors.grey[800],
                    padding:
                        EdgeInsets.symmetric(vertical: 20.0, horizontal: 20.0),
                    child: teamSettings(team, game),
                  );
                });
          },
          child: Container(
            color: Colors.transparent,
            margin: const EdgeInsets.fromLTRB(8, 1, 8, 10),
            child: Column(
              children: [
                Text(team.name, textAlign: TextAlign.center),
                const Spacer(),
                Text(team.score.toString(),
                    style: const TextStyle(fontSize: 40.0)),
              ],
            ),
          ),
        );
      },
    ),
  );
}

Widget teamSettings(Team team, Game game) {
  return Column(
    //crossAxisAlignment: CrossAxisAlignment.center,
    children: [
      Text(
        '${team.name} Config',
        style: TextStyle(
          fontSize: 24.0,
          color: Colors.white,
        ),
      ),
      Divider(),
      SizedBox(height: 20.0),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Text('Score', style: TextStyle(
              fontSize: 16.0)),
          ElevatedButton.icon(
            onPressed: () {
              team.addScore(-1);
              game.notifyModulesScore();
              //Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue,
            ),
            icon: Icon(Icons.remove, color: Colors.white),
            label: Text('Sub', style: TextStyle(color: Colors.white)),
          ),
          //Text(team.score.toString()),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue,
            ),
            icon: Icon(Icons.add, color: Colors.white),
            label: Text('Add', style: TextStyle(color: Colors.white)),
            onPressed: () {
              team.addScore(1);
              game.notifyModulesScore();
              //Navigator.pop(context);
            },
          ),
        ],
      ),
    ],
  );
}

Future<bool> _showExitDialog(BuildContext context) async {
  bool? exitApp = await showDialog(
      context: context,
      useSafeArea: true,
      builder: (context) => AlertDialog(
            backgroundColor: Colors.grey[800],
            title: const Text("Exit", style: TextStyle(color: Colors.white)),
            content: const Text('Do you want to exit application?'),
            actions: [
              ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red[500],
                  ),
                  onPressed: () {
                    Navigator.of(context).pop(true);
                  },
                  child: const Text('Exit',
                      style: TextStyle(color: Colors.white))),
              ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue[500],
                  ),
                  onPressed: () {
                    Navigator.of(context).pop(false);
                  },
                  child: const Text(
                    'Return',
                    style: TextStyle(color: Colors.white),
                  )),
            ],
          ));
  return exitApp ?? false;
}
